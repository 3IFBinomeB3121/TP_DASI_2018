/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author William
 */
public class JpaUtil {
    
    
    
    public static void createPersistenceContext() {
        em = EMF.createEntityManager();
    }
    
    public static EntityManager getPersistenceContext() {
        return em;
    }
    
    public static void beginTransaction() {
        em.getTransaction().begin();
    }
    
    public static void validateTransaction(){
        em.getTransaction().commit();
    }
    
    public static void cancelTransaction() {
        em.getTransaction().rollback();
    }
    
    public static void closePersistenceContext() {
        if(em.isOpen()){
            em.close();
        }
        
    }
    
    private static EntityManager em;
    private static final EntityManagerFactory EMF = Persistence.createEntityManagerFactory("PERS_UNIT_TD1");
}
