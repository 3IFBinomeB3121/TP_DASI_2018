/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import modele.Personne;
import dao.JpaUtil;
import dao.PersonneDAO;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.persistence.Query;
/**
 *
 * @author William
 */
public class servicePersonne {
    
    public static void ajouterPersonne(String n, String p, int a, Date d, String adr) {
        //On crée l'objet Personne correspondant
        Personne pers = new Personne(n,p,a,d,adr);
        //On vérifie si l'entity manager est ouvert
        JpaUtil.createPersistenceContext();
        //On commence une transaction
        JpaUtil.beginTransaction();
        //On rend l'objet persistant
        PersonneDAO.persistPersonne(pers);
        //On commit la transaction
        JpaUtil.validateTransaction();
    }
    
    public static void afficherPersonnesPersistantes(){
        Query query = JpaUtil.getPersistenceContext().createQuery("SELECT p FROM Personne p");
        List<Personne> res = (List<Personne>)query.getResultList();
        for (Iterator<Personne> it = res.iterator(); it.hasNext();){
            Personne tmp = it.next();
            System.out.println(tmp);
        }
    }
    
    public static void fermer(){
        JpaUtil.closePersistenceContext();
    }
}
