package vue;


import java.util.Date;
import service.servicePersonne;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author William
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Date d1 = new Date(97,03,03);
        Date d2 = new Date(100,01,25);
        Date d3 = new Date(-3,07,30);
        servicePersonne.ajouterPersonne("Michael", "Jackson", 22, d1,"1900 route de Vins, 83143, LE VAL");
        servicePersonne.ajouterPersonne("Salvador", "Henri", 98,d2,"Place Carami, 83170, BRIGNOLES");
        servicePersonne.ajouterPersonne("Brel", "Jacques", 32,d3,"93 Avenue Roger Salengro, 69100, VILLEURBANNE");
        servicePersonne.ajouterPersonne("Jonas", "Michel", 40,d2,"20 Avenue Albert Einstein, 69100, VILLEURBANNE");
        
        servicePersonne.afficherPersonnesPersistantes();
        
        servicePersonne.fermer();
    }   
    
}
